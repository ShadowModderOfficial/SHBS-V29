class Battle:
	onlineBattle=[{'index':0,'plr_count':0,'Tick':0,'plrs':[]}]