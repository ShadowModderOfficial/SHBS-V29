# Requirements:
1. a brain...

# Working:
1. Friend (add, status, remove)
2. Club
3. Shop
4. Online Rooms
5. bot interacting with the server
6. Brawl Pass
and more

# How to play SHBS V29:
1. download client
2. download server
3. download pydroid (if you want to run from the phone)
4. open in pydroid core.py located in the server folder
5. click on the run button
6. now open the game and play